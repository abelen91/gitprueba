def llamandomodulocliente():
    print("Acá estoy llamando al modulo cliente: ")
    