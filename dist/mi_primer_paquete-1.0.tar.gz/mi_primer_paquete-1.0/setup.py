from setuptools import setup

setup(
    name="mi_primer_paquete",
    version="1.0",
    description="Estoy realizando mi primer paquete distribuible",
    author="Ana Belen - Curso Python",
    author_email="abelen.n90@gmail.com",
    
    packages=["mi_primer_paquete"],
    
     )  

